create trigger square4
on form2
after insert
as 
begin
declare @y as int
declare @x as int=1

select top 1 @y= form2.val
from form2
order by form2.id desc

set @x = floor(sqrt(@y))


print @y
if @x*@x=@y
begin
print 'good'
end
end
go

