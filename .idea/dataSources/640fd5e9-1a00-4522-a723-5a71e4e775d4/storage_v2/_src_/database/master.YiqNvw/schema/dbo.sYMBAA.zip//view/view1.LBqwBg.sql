create view view1
as (select id,val from form1 where id<50)
go

