create trigger square
on form1
for insert
as 
begin
declare @y as int
declare @x as int
select top 1 val as y
from form1
order by id desc
set @x = floor(sqrt(@y))
if @x*@x=@y
begin
print 'good'
end
end
go

