create procedure borrowbook
	@username varchar(255),
	@bookname varchar(255)
as
	declare @founduser varchar(255)
	declare @booknum int
	select @founduser=username
	from account
	where username=@username
	if @founduser is null
	begin print 'user not exist' end
	else
	begin
		select @booknum=amount
		from storage
		where bookname=@bookname
		if @booknum is null
		begin print 'no such book' end
		else
		begin
			if @booknum<1
			begin print 'not enough' end
			else
			begin
				print 'done'
				update storage set amount=@booknum-1 where bookname=@bookname
			end
		end
	end
go

